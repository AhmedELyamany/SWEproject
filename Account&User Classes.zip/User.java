package BooksNetwork.User;

import java.util.Vector;

public class User {

  private int MobNum;
  private String Email;
  private Account account;
  private Vector<Account> acc;

  public void setMobNum(int mobNum) {
	MobNum = mobNum;
  }

  public void setEmail(String email) {
	Email = email;
  }

  public void updatePassword(String pw) {
	 Account.setPassword(pw);
	 System.out.println("Password updated successfully.");
  }

  public String DisplayInfo() {
     return  "First name: " + Account.Fname + "\nLast name: " + Account.Lname + 
	 "\nBirthdate: " + Account.Bdate + "\nUsername: " + Account.Username +
	 "\nPassword: " + Account.Password + "\nGender: " +Account.Gen;
  }

  public void setAccount(Account account) {
	this.account = account;
  }

  public void setAcc(Vector<Account> acc) {
	this.acc = acc;
  }
 
}