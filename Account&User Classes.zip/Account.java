package BooksNetwork.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Account {

  static String Fname;
  static String Lname;
  static String Bdate;
  static String Username;
  static String Password;
  static String Gen;
  private User user;
  private Vector <User> myUser;
  private Vector <Community>  myCommunity;
  private Vector <Account> accs;  
    
  public Account(String Fn, String Ln, String BD, String un, String pw, String G)
  {
	  Fname = Fn;
	  Lname = Ln;
	  Bdate = BD;
	  Username = un;
	  Password = pw;
	  Gen 	= G; 
  }

  public void setFname (String fn) { 
	  Fname = fn; 
  } 

  public void setLname (String ln) { 
	  Lname = ln; 
  } 

  public void setBdate (String bd) { 
	  Bdate = bd; 
  } 

  public void setUsername (String un) { 
	  Username = un; 
  } 

  public static void setPassword (String passw) { 
	  Password = passw; 
  }
  public void setGender (String g) {
	  Gen = g;
  }
  
  public void setUser(User user) {
	this.user = user;
  }
  
  public void setMyUser(Vector <User> myUser) {
	this.myUser = myUser;
  }

  public void setMyCommunity(Vector <Community> myCommunity) {
	this.myCommunity = myCommunity;
  }

  public void Signup(String un) throws Exception {
	  
	  try {
	     if (Username != null && Password!=null && Bdate != null &&
	    	 Fname != null && Lname !=null && Gen != null) {
	   
	    Class.forName("com.mysql.jdbc.Driver");
	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/accounts","root","");
	    Statement statement = con.createStatement();
	    String sql = "Select * from usersdata Where UserName='" + Username + "'";
	    ResultSet result = statement.executeQuery(sql);
	    
	      if(result.next()){
	           System.out.println("Sorry, Username is already taken!");
	      } 
	      
	      if(Username == null || Password == null || Bdate == null ||
	 	     Fname == null || Lname == null || Gen == null){
	    	  System.out.println("you must fill in all the data!");
	      }
	      
	      else {
	    	 System.out.println("Signup is complete, you can access your account now!");
	    	 
	    	 //Add new data to Database
	    	 PreparedStatement statmnt = (PreparedStatement) con.prepareStatement
	    	("INSERT INTO usersdata(FirstName,LastName,BirthDate,UserName,Password,Gender) values (Fname,Lname,Bdate,Username,Password,Gen)");
	    	 statmnt.setString(1, Fname);
	    	 statmnt.setString(2, Lname);
	    	 statmnt.setString(3, Bdate);
	    	 statmnt.setString(4, Username);
	    	 statmnt.setString(5, Password);
	    	 statmnt.setString(6, Gen);
	    	 statmnt.executeUpdate();    	 
	      }
	  }

	   } catch (SQLException e) {
		   
		   System.out.println("Error" + e.getMessage());
	   }
  }

  public void login(String un,String pw) throws Exception {
	  try {
      if (Username != null && Password!=null) {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/accounts","root","");
    Statement statement = con.createStatement();
    String sql = "Select * from usersdata Where UserName='" + Username + "' and Password = '" + Password + "'";
    ResultSet result = statement.executeQuery(sql);
      if(result.next()){
           System.out.println("Welcome " + Username + " :) ");
      } else {
    	  System.out.println("Login failed!");
      }
  }

   } catch (SQLException e) {
	   
	   System.out.println("Error" + e.getMessage());
   }

  }

  public void Signout() {
	  
	// n3mlha b3d el GUI, as form, y3ni bdl mn-terminate, nerga3 L awl form
	// w y3ml login tani, k2no bi-switch user msln
  }

}